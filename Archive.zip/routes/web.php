<?php

use Illuminate\Support\Facades\Route;

// default page is login page
Route::get('/', 'App\Http\Controllers\Login@index');

// route login
Route::get('login', 'App\Http\Controllers\Login@index');
Route::get('login/lupa', 'App\Http\Controllers\Login@lupa');
Route::post('login/proses-login', 'App\Http\Controllers\Login@proses_login');

// route ari
Route::get('ari', 'App\Http\Controllers\Ari@index');
Route::get('ari/beranda', 'App\Http\Controllers\Ari@beranda');
Route::get('ari/profil', 'App\Http\Controllers\Ari@profil');
Route::get('ari/kontak', 'App\Http\Controllers\Ari@kontak');

// ADMINISTRATOR ROUT
// dasbor
Route::get('admin/dasbor', 'App\Http\Controllers\Admin\Dasbor@index');

// user dan pengguna
Route::get('admin/user', 'App\Http\Controllers\Admin\User@index');
Route::get('admin/user/tambah', 'App\Http\Controllers\Admin\User@tambah');
Route::get('admin/user/edit/{id}', 'App\Http\Controllers\Admin\User@edit');
Route::get('admin/user/delete/{id}', 'App\Http\Controllers\Admin\User@delete');
Route::post('admin/user/proses-tambah', 'App\Http\Controllers\Admin\User@proses_tambah');
Route::post('admin/user/proses-edit', 'App\Http\Controllers\Admin\User@proses_edit');

// jenis-produk
Route::get('admin/jenis-produk', 'App\Http\Controllers\Admin\Jenis_produk@index');
Route::get('admin/jenis-produk/tambah', 'App\Http\Controllers\Admin\Jenis_produk@tambah');
Route::get('admin/jenis-produk/edit/{id}', 'App\Http\Controllers\Admin\Jenis_produk@edit');
Route::get('admin/jenis-produk/delete/{id}', 'App\Http\Controllers\Admin\Jenis_produk@delete');
Route::post('admin/jenis-produk/proses-tambah', 'App\Http\Controllers\Admin\Jenis_produk@proses_tambah');
Route::post('admin/jenis-produk/proses-edit', 'App\Http\Controllers\Admin\Jenis_produk@proses_edit');