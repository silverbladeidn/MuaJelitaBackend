<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Login extends Controller
{
    // index
    public function index()
    {
        $data = [   'title'     => 'Halaman Login',
                    'content'   => 'login/index'
                ];
        return view('login/wrapper',$data);
    }

    // lupa
    public function lupa()
    {
        $data = [   'title'     => 'Lupa Password',
                    'content'   => 'login/lupa'
                ];
        return view('login/wrapper',$data);
    }
}
