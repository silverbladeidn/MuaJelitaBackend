<section class="footer1 cid-teEbUDniP1" id="footer1-4">

    

    <div class="container">
        <div class="align-center mbr-p-1">
            <p class="mbr-text mbr-white mbr-fonts-style display-7">
                © Copyright 2025 Mobirise - All Rights Reserved
            </p>
        </div>
    </div>
</section><section class="display-7" style="padding: 0;align-items: center;justify-content: center;flex-wrap: wrap;    align-content: center;display: flex;position: relative;height: 4rem;"><a href="https://mobiri.se/596719" style="flex: 1 1;height: 4rem;position: absolute;width: 100%;z-index: 1;"><img alt="" style="height: 4rem;" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="></a><p style="margin: 0;text-align: center;" class="display-7">Created with Mobirise ‌</p><a style="z-index:1" href="https://mobirise.com/html-builder.html">HTML Page Generator</a></section>
  
  
</body>
</html>