@include('admin/konsumsi/tambah')

<table class="table table-sm table-bordered mt-5">
	<thead>
		<tr>
			<th>No</th>
			<th>Kota</th>
			<th>Tahun</th>
			<th>Konsumsi Perkapita</th>
			<th>Status</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
		<?php $no=1; foreach($konsumsi as $konsumsi) { ?>
		<tr>
			<td><?php echo $no ?></td>
			<td><?php echo $konsumsi->nama_kota ?></td>
			<td><?php echo $konsumsi->tahun ?></td>
			<td><?php echo number_format($konsumsi->jumlah) ?></td>
			<td><?php echo $konsumsi->status_konsumsi ?></td>
			<td>
				<a href="{{ asset('admin/konsumsi/edit/'.$konsumsi->id_konsumsi) }}" class="btn btn-secondary btn-sm">
					<i class="bi bi-pencil"></i>
				</a>
				<a href="{{ asset('admin/konsumsi/delete/'.$konsumsi->id_konsumsi) }}" class="btn btn-secondary btn-sm delete-link" >
					<i class="bi bi-trash"></i>
				</a>
			</td>
		</tr>
		<?php $no++; } ?>
	</tbody>
</table>
