<div class="login-box">
        <div class="login-logo"> <a href="<?php echo e(asset('/')); ?>"><b>ROYANI</b>APPS</a> </div> <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to start your session</p>


                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
                <?php endif; ?>

                <form action="<?php echo e(asset('login/proses')); ?>" method="post">
                <?php echo e(csrf_field()); ?>  

                    <div class="input-group mb-3"> 
                        <input type="text" name="username" class="form-control" placeholder="Username">
                        <div class="input-group-text"> <span class="bi bi-envelope"></span> </div>
                    </div>
                    <div class="input-group mb-3"> 
                        <input type="password" name="password" class="form-control" placeholder="Password">
                        <div class="input-group-text"> <span class="bi bi-lock-fill"></span> </div>
                    </div> <!--begin::Row-->
                    <div class="row">
                        <div class="col-8">
                            <div class="form-check"> <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"> <label class="form-check-label" for="flexCheckDefault">
                                    Remember Me
                                </label> </div>
                        </div> <!-- /.col -->
                        <div class="col-4">
                            <div class="d-grid gap-2"> <button type="submit" class="btn btn-primary">Sign In</button> </div>
                        </div> <!-- /.col -->
                    </div> <!--end::Row-->
                </form>
                
                <hr>
                <p class="mb-0 text-center"> 
                    <a href="<?php echo e(asset('/')); ?>" class="text-center">
                        Beranda
                    </a> | 
                    Lupa password? 
                    <a href="<?php echo e(asset('login/reset')); ?>" class="text-center">
                        Reset
                    </a>
                </p>
            </div> <!-- /.login-card-body -->
        </div>
    </div> <!-- /.login-box --> <!--begin::Third Party Plugin(OverlayScrollbars)--><?php /**PATH C:\xampp\htdocs\royani\resources\views/login/index.blade.php ENDPATH**/ ?>