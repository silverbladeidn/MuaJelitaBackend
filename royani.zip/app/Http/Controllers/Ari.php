<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Ari extends Controller
{
    // index
    public function index()
    {
        echo 'Ini halaman index';
    }

    // beranda
    public function beranda()
    {
        echo 'Ini beranda';
    }

    // kontak
    public function kontak()
    {
        echo 'Ini kontak';
    }

    // profil
    public function profil()
    {
        echo 'Ini profil';
    }
}
