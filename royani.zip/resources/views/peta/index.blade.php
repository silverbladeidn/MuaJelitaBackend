<section class="mbr-section 01 cid-teEd8Ixe48" id="content1-7">
     <div class="container pt-5 mt-5">
        <div class="mbr-row mbr-jc-c pt-5">
            <div class="mbr-col-sm-12 mbr-col-md-10">
                <h2 class="mbr-section-title align-center mbr-fonts-style mbr-bold display-2">
                    {{ $title }}</h2>
            </div>
        </div>
    </div>
</section>

<section class="features1 mbr-section cid-teEc9ptebc" id="features1-6">
    <div class="container">
        <div class="mbr-row mbr-jc-c">
           
            @include('home/map')
            
        </div>
    </div>
</section>
