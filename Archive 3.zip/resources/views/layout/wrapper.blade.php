@include('layout/head')
@include('layout/header')
@include($content)
@include('layout/footer')